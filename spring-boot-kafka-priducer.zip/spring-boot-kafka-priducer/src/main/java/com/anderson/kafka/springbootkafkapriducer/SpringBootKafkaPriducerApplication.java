package com.anderson.kafka.springbootkafkapriducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKafkaPriducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKafkaPriducerApplication.class, args);
	}

}
